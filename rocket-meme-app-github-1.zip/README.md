# Rocket Meme AI

This is a real-time crypto meme coin prediction app using live data from CoinGecko and Whale Alert APIs. Deploy with GitHub Pages or Netlify.